from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
import requests
from .models import Messages
import re
 # Setup the Google Sheets API

def extract_spreadsheet_id(url):

    pattern = r"/spreadsheets/d/([a-zA-Z0-9-_]+)"
    match = re.search(pattern, url)
    if match:
        return match.group(1)
    else:
        return "ID not found in the URL."



m = Messages()


# Create your views here.
def messagesender(request):
    return render(request, "messagesender/index.html")


def template_message_sender(request):

    print("receiving messages")
    global spreadsheet_url_from_user    
    
    
    if request.method == 'POST':
        template_name = request.POST.get('Templateoptions')
        print(template_name)

        url = request.POST.get("spreadsheet_url")
        print(url)
                      
        

        if (template_name == 'Tracking Message Sender'):
            print("sending tracking message", )

            

            SCOPES = ['https://www.googleapis.com/auth/spreadsheets.readonly']
            SERVICE_ACCOUNT_FILE = 'messagesender/google sheets api.json'

            credentials = Credentials.from_service_account_file(
                    SERVICE_ACCOUNT_FILE, scopes=SCOPES)

            # Call the Sheets API
            service = build('sheets', 'v4', credentials=credentials)
            sheet = service.spreadsheets()

            # Read the sheet data

            SPREADSHEET_ID = extract_spreadsheet_id(url)



            RANGE_NAME = 'Sheet1!A:E'  # Adjusted to include all columns you need
            result = sheet.values().get(spreadsheetId=SPREADSHEET_ID, range=RANGE_NAME).execute()
            values = result.get('values', [])


            url = "https://graph.facebook.com/v18.0/238565786002156/messages"

            headers = {
                'Authorization': f'Bearer EAALulZBaUFEoBO14KizIiMUCba2ATeGyJdZCcBgni1ilskzwZAousTBXfzAIlHrU6wdQoZCEjuUZCkzHCexuW08T7o5KZA8lEWm0YOmxEnbEu9wRMS6O7sNyKQRyL4WlNMNVK8Wl2ScVSXaOAZCVZCt3SqxdD3hpgBLA5EhxKV38QMGeagtRgD0Qkl63JTYXJeCZC',
                'Content-Type': 'application/json'
            }

            for row in values:
                if len(row) >= 5:  # Ensure there are at least five columns with data
                    customer_name = row[0]  # Customer's name from column A
                    phone_number = row[1]   # Phone number from column B
                    company_name = row[2]   # Company name from column C
                    tracking_number = row[3]  # Tracking number from column D
                    website = row[4]  # Website from column E

            # Construct the data payload for the API request
                    data = {
                    "messaging_product": "whatsapp",
                    "to": phone_number,
                    "type": "template",
                    "template": {
                        "name": "placeholder",  # Use the actual template name you set on WhatsApp Manager
                        "language": {
                            "code": "en_US"
                        },
                        "components": [{
                            "type": "body",
                            "parameters": [
                                {"type": "text", "text": customer_name},
                                {"type": "text", "text": company_name},
                                {"type": "text", "text": tracking_number},
                                {"type": "text", "text": website}
                            ]
                        }]
                    }
                }
                    response = requests.post(url, headers=headers, json=data)
                    if response.status_code == 200:
                       messagesent = f"Message sent to {customer_name} ({phone_number}) successfully."
                       print(messagesent)
                       messages.success(request, messagesent)  # This stores the message in the request
                       m.successfully_message_sent = messagesent
                       print(messagesent)

                    else:
                        failedmessagesent = f"Failed to send message to {customer_name} {phone_number}{response.text}"
                        messages.error(request,failedmessagesent)
                        m.failed_message_sent = failedmessagesent
                        print(failedmessagesent)
                m.save()
            else:
                print("eror")

        elif(template_name == 'Image Message Sender'):
            return render(request, 'messagesender/imagemessagesender.html')
        elif(template_name == 'Video Message Sender'):
            return redirect ("/all-services/video-message-sender/")


            

        
    return redirect ("/all-services/message-sender/")

def send_image_message(request):
    return render(request,("messagesender/iamgemessagesender.html"))

def imagemessagesenderroute(request):
    if request.method == "POST":

        url = request.POST.get("spreadsheet_url")

        SCOPES = ['https://www.googleapis.com/auth/spreadsheets.readonly']
        SERVICE_ACCOUNT_FILE = 'messagesender/google sheets api.json'

        credentials = Credentials.from_service_account_file(
                SERVICE_ACCOUNT_FILE, scopes=SCOPES)

        # Call the Sheets API
        service = build('sheets', 'v4', credentials=credentials)
        sheet = service.spreadsheets()

        # Read the sheet data

        SPREADSHEET_ID = extract_spreadsheet_id(url)
        print(url)



        RANGE_NAME = 'Sheet1!A:E'  # Adjusted to include all columns you need
        result = sheet.values().get(spreadsheetId=SPREADSHEET_ID, range=RANGE_NAME).execute()
        values = result.get('values', [])


        url = "https://graph.facebook.com/v18.0/238565786002156/messages"

        headers = {
            'Authorization': f'Bearer EAALulZBaUFEoBO14KizIiMUCba2ATeGyJdZCcBgni1ilskzwZAousTBXfzAIlHrU6wdQoZCEjuUZCkzHCexuW08T7o5KZA8lEWm0YOmxEnbEu9wRMS6O7sNyKQRyL4WlNMNVK8Wl2ScVSXaOAZCVZCt3SqxdD3hpgBLA5EhxKV38QMGeagtRgD0Qkl63JTYXJeCZC',
            'Content-Type': 'application/json'
        }
        print("get an post request")        
        # Gather inputs once before the loop
        template_name = "imagesender"
        header_image_url = request.POST.get("enter_url_of_media")  # Or use header_media_id if you have one
        temptext = request.POST.get("enter_text_message")
        websiteurl = request.POST.get("enter_website_url")
        for row in values:
            if len(row) >= 2:  # Check if there are at least two columns
                customer_name = row[0]  # First phone number
                phone_number = row[1]  # Second phone number


                # The data payload for the request
                data = {
                "messaging_product": "whatsapp",
                "to": phone_number,
                "type": "template",
                "template": {
                    "name": "imagesender",
                    "language": {
                    "code": "en_US"
                    },
                "components": [
                    {
                        "type": "header",
                        "parameters": [
                            {
                                "type": "image",
                                "image": {
                                    "link": header_image_url
                                }
                            }
                        ]
                    },
                    {
                        "type": "body",
                        "parameters": [
                            {
                                "type": "text",
                                "text": temptext
                            }
                        ]
                    },
                    {
                        "type": "button",
                        "sub_type": "url",
                        "index": 0,
                        "parameters": [
                            {
                                "type": "text",
                                "text": websiteurl  
                            }
                        ]
                    }
                ]
                }
                }
                # Send the POST request
                response = requests.post(url, headers=headers, json=data)

                # Check the response from WhatsApp
                if response.status_code == 200:
                    messagesent = f"Message sent to {customer_name} ({phone_number}) using {template_name}successfully."
                    print(messagesent)
                    messages.success(request, messagesent)  # This stores the message in the request
                    m.successfully_message_sent = messagesent
                    
                
                else:
                    messages.error(request, f"Failed to send message to {customer_name} ({phone_number}) by {template_name}")
            else:
                
                print("error")
    
    else:
        print("didnt get a post request")

    return render(request, ("messagesender/imagemessagesended.html"))


def send_video_message(request):
    return render (request, ("messagesender/videomessagesender.html"))
    
def videomessagesenderroute(request):
    # Gather inputs once before the loop
    template_name = "mark4"
    # header_video_url = input("Enter the URL of the video: ")  # Or use header_media_id if you have one
    # websiteurl = input(str("enter the url of the website something like: /products/chocolate-plain-crep : "))
    # temptext = input("Enter The Text Message You Want To Send: ")
    # temptext = "temp text"
                                        # "link": header_video_url  # Ensure this is a direct link to an image file
    if request.method == "POST":



        url = request.POST.get("spreadsheet_url")
                      
        


        SCOPES = ['https://www.googleapis.com/auth/spreadsheets.readonly']
        SERVICE_ACCOUNT_FILE = 'messagesender/google sheets api.json'

        credentials = Credentials.from_service_account_file(
                SERVICE_ACCOUNT_FILE, scopes=SCOPES)

        # Call the Sheets API
        service = build('sheets', 'v4', credentials=credentials)
        sheet = service.spreadsheets()

        # Read the sheet data

        SPREADSHEET_ID = extract_spreadsheet_id(url)



        RANGE_NAME = 'Sheet1!A:E'  # Adjusted to include all columns you need
        result = sheet.values().get(spreadsheetId=SPREADSHEET_ID, range=RANGE_NAME).execute()
        values = result.get('values', [])


        url = "https://graph.facebook.com/v18.0/238565786002156/messages"

        headers = {
            'Authorization': f'Bearer EAALulZBaUFEoBO14KizIiMUCba2ATeGyJdZCcBgni1ilskzwZAousTBXfzAIlHrU6wdQoZCEjuUZCkzHCexuW08T7o5KZA8lEWm0YOmxEnbEu9wRMS6O7sNyKQRyL4WlNMNVK8Wl2ScVSXaOAZCVZCt3SqxdD3hpgBLA5EhxKV38QMGeagtRgD0Qkl63JTYXJeCZC',
            'Content-Type': 'application/json'
        }
        header_video_url = request.POST.get("enter_url_of_media")
        print(header_video_url)
        temptext = request.POST.get("enter_text_message")
        print(temptext)
        websiteurl = request.POST.get("enter_website_url")
        print(websiteurl)
        for row in values:
            if len(row) >= 2:  # Check if there are at least two columns
                customer_name = row[0]  # First phone number
                phone_number = row[1]  # Second phone number

                # The data payload for the request
                data = {
                    "messaging_product": "whatsapp",
                    "to": phone_number,
                    "type": "template",
                    "template": {
                        "name": "mark4",
                        "language": {
                            "code": "en_US"
                        },
                        "components": [
                            {
                                "type": "header",
                                "parameters": [
                                    {
                                        "type": "video",
                                        "video": {
                                            "link": header_video_url  # Ensure this is a direct link to an video file
                                        }
                                    }
                                ]
                            },
                            {
                                "type": "body",
                                "parameters": [
                                    {
                                        "type": "text",
                                        "text": temptext   # The first placeholder value
                                    },
                                ]
                            },
                            {
                                "type": "button",
                                "sub_type": "url",
                                "index": 0,
                                "parameters": [
                                    {
                                        "type": "text",
                                        "text": websiteurl  
                                    }
                                ]
                                        }
                            # Include any other components that your template might have, like buttons
                        ]
                    }
                }

                # Send the POST request
                try:
                    response = requests.post(url, headers=headers, json=data)

                    # Check the response from WhatsApp
                    if response.status_code == 200:
                        messagesent = f"Message sent to {customer_name} ({phone_number}) successfully."
                        print(messagesent)
                        messages.success(request, messagesent)  # This stores the message in the request
                    
                    else:
                        print(f"Failed to send message to {customer_name} ({phone_number}). Status code: {response.status_code}, Response: {response.text}")
                except:
                    messages.error(request, f"Failed to send message to {customer_name} {phone_number} BY {template_name}")

            else:
                    print("something went wrong said by except")
    else:
        print("this is a get request of message sended route")
    
    return render(request, ("messagesender/videomessagesended.html"))