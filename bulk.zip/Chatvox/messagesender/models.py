from django.db import models

# Create your models here.

class Messages(models.Model):
    successfully_message_sent = models.CharField(max_length=500)
    failed_message_sent = models.CharField(max_length=500)